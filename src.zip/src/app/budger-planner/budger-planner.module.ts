import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BudgerPlannerRoutingModule } from './budger-planner-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    BudgerPlannerRoutingModule
  ]
})
export class BudgerPlannerModule { }
