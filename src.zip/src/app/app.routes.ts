import { Routes } from '@angular/router';

export const routes: Routes = [
    {path:'budget-planner',loadChildren:()=> import('./budger-planner/budger-planner.module').then(m=> m.BudgerPlannerModule)}
];
